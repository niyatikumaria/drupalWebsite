/* @license GPL-2.0-or-later https://www.drupal.org/licensing/faq */
(function(Drupal){'use strict';Drupal.behaviors.addToAny={attach:function(context,settings){if(context!==document&&window.a2a)a2a.init_all();}};})(Drupal);;
